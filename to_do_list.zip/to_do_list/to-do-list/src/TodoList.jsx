import React, { useState } from "react";

function TodoList(){

    const [tasks, setTasks] = useState([]);

    const [newTask, setNewTask] = useState("");

    function handleInputChange(event){
        setNewTask(event.target.value);
    }

    function addTask(){
        if(newTask.trim() !== ""){
            setTasks(t => [
                ...t,
                { text: newTask, completed: false }
            ]);
            setNewTask("");
        }
    }

    function deleteTask(index){
        const updatedTasks = tasks.filter((_, i) => i !== index);
        setTasks(updatedTasks);
    }

    function moveTaskUp(index){
        if(index > 0 && !tasks[index].completed){
            const updatedTasks = [...tasks];
            [updatedTasks[index], updatedTasks[index - 1]] =
            [updatedTasks[index - 1], updatedTasks[index]];
            setTasks(updatedTasks);
        }
    }

    function moveTaskDown(index){
        if(index < tasks.length - 1 && !tasks[index].completed){
            const updatedTasks = [...tasks];
            [updatedTasks[index], updatedTasks[index + 1]] =
            [updatedTasks[index + 1], updatedTasks[index]];
            setTasks(updatedTasks);
        }
    }

    function completeTask(index){
        setTasks(prevTasks => {
            const updatedTasks = [...prevTasks];
            const completedTask = {
                ...updatedTasks[index],
                completed: true
            };

            updatedTasks.splice(index, 1);
            updatedTasks.push(completedTask);

            return updatedTasks;
        });
    }

    return(
        <div className="to-do-list">
            <h1>TO-DO-LIST</h1>

            <div>
                <input
                    type="text"
                    placeholder="enter a task..."
                    value={newTask}
                    onChange={handleInputChange}
                />
                <button className="add-btn" onClick={addTask}>
                    ADD
                </button>
            </div>

            <ol>
                {tasks.map((task, index) => (
                    <li
                        key={index}
                        className={task.completed ? "completed-task" : ""}
                    >
                        <span className="text">{task.text}</span>

                        <button
                            className="delete-btn"
                            onClick={() => deleteTask(index)}
                        >
                            DELETE
                        </button>

                        <button
                            className="move-btn"
                            onClick={() => moveTaskUp(index)}
                            disabled={task.completed}
                        >
                            UP
                        </button>

                        <button
                            className="move-btn"
                            onClick={() => moveTaskDown(index)}
                            disabled={task.completed}
                        >
                            DOWN
                        </button>

                        <button
                            className="complete-btn"
                            onClick={() => completeTask(index)}
                            disabled={task.completed}
                        >
                            {task.completed ? "COMPLETED" : "COMPLETE"}
                        </button>
                    </li>
                ))}
            </ol>
        </div>
    );
}

export default TodoList;
