import TodoList from './TodoList.jsx';

function App() {
  

  return (
    <>
    <TodoList/>
    </>
  )
}

export default App
